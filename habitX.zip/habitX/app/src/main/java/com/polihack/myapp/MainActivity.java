package com.polihack.myapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.polihack.cmlibrary.CircleMenu;
import com.polihack.cmlibrary.OnMenuSelectedListener;

/**
 * Input checking system :
 *  - verify every single TIME input (system time, valid input)
 *  - make a "schedue" by setting up the wake-up and bed-time TIMES, to provide
 *    correctness of the introduces Breakfast, Dinner, Lunch data, which will be
 *    possible to set ONCE
 *  - calculate the score as correctly as possible, and send it to the server
 *  - solve the 'getValue.php' problematic, the sort fetch-line and to list the
 *    users in descending order, setting up the 'Black Sheep' of the group every
 *    midnight, which is the GLOBAL RESET to the : FoodInput, WakeUp, BedTime, the
 *    Score of the day(flush, removeFromPrefs)
 *
 *  - score calculator : local statics for every single field, this is stored locally ->
 *    send to the database, then at midnight make the GetValue fetch, and display the
 *    ranking of the day, with the BlackSheep.
 *
 *      At a fix hour 'score' gets to the server, is contracted with the all other information
 *      and sent back, is arranged and the RANKING is set up. Every day.
 *
 */

/**
 *  * COPYRIGHT :
 *  Hugs for Bugs team : Daczó Melinda, Florea Adrian, Kis Balázs
 *  Polihack v7.0 start of the app : local database, finite nr. of the lobby users.
 *
 *  2018.05.11
 */
public class MainActivity extends AppCompatActivity {

    String name = "ic_add";
    int dailyValue = 50;
    ///statics for points + the wake-up/bedtime

    String Wake_Up_Time;
    String Sleep_Time;
    TextView text_intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent Login = getIntent();
        final String myname = Login.getStringExtra("username");

        final TextView namee = (TextView) findViewById(R.id.myname);
        namee.setText(myname);

        String aux = getFromPrefs(this, "dailyValue", dailyValue + "");
        dailyValue = Integer.parseInt(aux);

        name = getFromPrefs(this, "pic_name", name);

        Resources res = this.getResources();
        int resID = res.getIdentifier(name, "drawable", this.getPackageName());

        text_intent = (TextView) findViewById(R.id.text_intent);

        final CircleMenu circleMenu = (CircleMenu) findViewById(R.id.circle_menu);
        circleMenu.setMainMenu(Color.parseColor("#FFFFFF"), resID, R.drawable.ic_remove)
                .addSubMenu(Color.parseColor("#FFFFFF"), R.drawable.av_g2)
                .addSubMenu(Color.parseColor("#FFFFFF"), R.drawable.av_g1)
                .addSubMenu(Color.parseColor("#FFFFFF"), R.drawable.av_b3)
                .addSubMenu(Color.parseColor("#FFFFFF"), R.drawable.av_b1)
                .addSubMenu(Color.parseColor("#FFFFFF"), R.drawable.av_b2)
                .addSubMenu(Color.parseColor("#FFFFFF"), R.drawable.av_g3)
                .setOnMenuSelectedListener(new OnMenuSelectedListener() {
                    @Override
                    public void onMenuSelected(int index) {
                        if(index == 0) {
                            circleMenu.setMainMenu(Color.parseColor("#FFFFFF"), R.drawable.av_g2, R.drawable.ic_remove);
                            name = "av_g2";
                        }
                        else if(index == 1)
                        {
                            circleMenu.setMainMenu(Color.parseColor("#FFFFFF"), R.drawable.av_g1, R.drawable.ic_remove);
                            name = "av_g1";
                        }
                        else if(index == 2)
                        {
                            circleMenu.setMainMenu(Color.parseColor("#FFFFFF"), R.drawable.av_b3, R.drawable.ic_remove);
                            name = "av_b3";
                        }
                        else if(index == 3)
                        {
                            circleMenu.setMainMenu(Color.parseColor("#FFFFFF"), R.drawable.av_b1, R.drawable.ic_remove);
                            name = "av_b1";
                        }
                        else if(index == 4)
                        {
                            circleMenu.setMainMenu(Color.parseColor("#FFFFFF"), R.drawable.av_b2, R.drawable.ic_remove);
                            name = "av_b2";
                        }
                        else if(index == 5)
                        {
                            circleMenu.setMainMenu(Color.parseColor("#FFFFFF"), R.drawable.av_g3, R.drawable.ic_remove);
                            name = "av_g3";
                        }
                    }
                });
        Intent intent = getIntent();
        Wake_Up_Time = intent.getStringExtra("WTime");
        Sleep_Time = intent.getStringExtra("STime");
        dailyValue = intent.getIntExtra("value", dailyValue);


        text_intent.setText(Wake_Up_Time);
        text_intent.setText(Sleep_Time);

        TextView scores = (TextView) findViewById(R.id.score);
        scores.setText(dailyValue + "");

        saveToPrefs(getBaseContext(), "username", myname);
        /**the button to go to set the needed information**/
        ImageButton toSettings = (ImageButton) findViewById(R.id.toSettings);
        toSettings.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                saveToPrefs(getBaseContext(), "pic_name", name);
                Intent toSettingsActivity = new Intent(MainActivity.this, PlanActivity.class);
                toSettingsActivity.putExtra("username", myname);
                startActivity(toSettingsActivity);
                MainActivity.this.finish();
            }
        });
        /**the button to go to check habits**/
        final ImageButton toTasks = (ImageButton) findViewById(R.id.toTasks);
        toTasks.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                saveToPrefs(getBaseContext(), "pic_name", name);
                Intent toSettingsActivity = new Intent(MainActivity.this, HabitsActivity.class);
                toSettingsActivity.putExtra("dailyValue", dailyValue);
                toSettingsActivity.putExtra("username", myname);
                startActivity(toSettingsActivity);
                MainActivity.this.finish();
            }
        });
        /**quit**/
        Button buttonQuit = (Button) findViewById(R.id.buttonQuit);
        buttonQuit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveToPrefs(getBaseContext(), "dailyValue", dailyValue + "");
                saveToPrefs(getBaseContext(), "pic_name", name);
                //removeFromPrefs(getBaseContext(), "dailyValue");
                System.exit(0);
            }
        });
        /**for the person, to see the score**/
        ProgressBar simpleProgressBar=(ProgressBar) findViewById(R.id.simpleProgressBar); // initiate the progress bar
        /**
         * set the value to be necessarily between [0-100]
         */
        simpleProgressBar.setProgress(dailyValue);
    }

    /**
     *
     * @param context Context -> this, in getFromPrefs, 'getBaseContext()' in saveToPrefs
     * @param key -> a name, to specify in save, to pull in get
     * @param value -> actual value
     */
    public static void saveToPrefs(Context context, String key, String value) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = prefs.edit();
        editor.putString(key,value);
        editor.commit();
    }
    public static String getFromPrefs(Context context, String key, String defaultValue) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        try {
            return sharedPrefs.getString(key, defaultValue);
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }
    }
    public static void removeFromPrefs(Context context, String key) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = prefs.edit();
        editor.remove(key);
        editor.commit();
    }
}
