package com.polihack.myapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class HabitsActivity extends AppCompatActivity {

    static int vBeingLate = -5;
    static int vJunkFood = -8;
    static int vFruit = 3;
    static int vBreakfast = 5;
    static int vLunch = 5;
    static int vDinner = 5;
    static int vCigarette = -5;
    static int vWater = 3;
    static int vTeethbrush = 2;

    int score;

    String breakfastTime;
    String lunchTime;
    String dinnerTime;
    String username;

    int cigar_count = 0;
    int water_count = 0;
    int brushing_count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_habits);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        Intent getScore = getIntent();
        score = getScore.getIntExtra("dailyValue", 0);
        username = getScore.getStringExtra("username");

        final EditText breakfast = (EditText) findViewById(R.id.etBreakfast);
        final EditText lunch = (EditText) findViewById(R.id.etLunch);
        final EditText dinner = (EditText)findViewById(R.id.etDinner);
         /**
         * fetch data from SharedPreference
         */

                breakfastTime = getFromPrefs(this, "breakfastTime", "");
                if (!breakfastTime.equals("")) {
                    breakfast.setText(breakfastTime);
                    //breakfast.setEnabled(false);
                }
                lunchTime = getFromPrefs(this, "lunchTime", "");
                if (!lunchTime.equals("")) {
                    lunch.setText(lunchTime);
                    //lunch.setEnabled(false);
                }
                dinnerTime = getFromPrefs(this, "dinnerTime", "");
                if (!dinnerTime.equals("")) {
                    dinner.setText(dinnerTime);
                    //dinner.setEnabled(false);
                }
         /**
         * all data to fetch
         */
        final Switch switch_beingLate = (Switch) findViewById(R.id.habit1);
        switch_beingLate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    score += vBeingLate;
                    }
                }
            });
        final Switch switch_junkFood = (Switch) findViewById(R.id.habit2);
        switch_junkFood.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    score += vJunkFood;
                }
            }
        });
        final Switch switch_fruit = (Switch) findViewById(R.id.habit3);
        switch_fruit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    score += vFruit;
                }
            }
        });

        final ImageButton cigar_contor = (ImageButton) findViewById(R.id.bCigarettes);
        cigar_contor.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                cigar_count++;
                saveToPrefs(getBaseContext(), "cigar_cunter", cigar_count + "");
                score += vCigarette;
            }
        });

        final ImageButton water_contor = (ImageButton) findViewById(R.id.bWater);
        water_contor.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                water_count++;
                saveToPrefs(getBaseContext(), "cigar_cunter", water_count + "");
                score += vWater;
            }
        });

        final ImageButton toothbrush_contor = (ImageButton) findViewById(R.id.bBrushing);
        toothbrush_contor.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                brushing_count++;
                saveToPrefs(getBaseContext(), "cigar_cunter", brushing_count + "");
                score += vTeethbrush;
            }
        });

        final ImageButton saveHabits = (ImageButton) findViewById(R.id.saveHabits);
        saveHabits.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                if (!breakfastTime.equals(breakfast.getText().toString()))
                    score += vBreakfast;
                breakfastTime = breakfast.getText().toString();
                saveToPrefs(getBaseContext(),"breakfastTime", breakfastTime);

                if (!lunchTime.equals(lunch.getText().toString()))
                    score += vLunch;
                lunchTime = lunch.getText().toString();
                saveToPrefs(getBaseContext(),"lunchTime", lunchTime);

                if (!dinnerTime.equals(dinner.getText().toString()))
                    score += vDinner;
                dinnerTime = dinner.getText().toString();
                saveToPrefs(getBaseContext(),"dinnerTime", dinnerTime);

                Intent toSettingsActivity = new Intent(HabitsActivity.this, MainActivity.class);
                toSettingsActivity.putExtra("value", score);
                toSettingsActivity.putExtra("username", username);
                startActivity(toSettingsActivity);
                HabitsActivity.this.finish();
            }
        });
    }
    public static void saveToPrefs(Context context, String key, String value) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        final SharedPreferences.Editor editor = prefs.edit();
        editor.putString(key,value);
        editor.commit();
    }
    public static String getFromPrefs(Context context, String key, String defaultValue) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        try {
            return sharedPrefs.getString(key, defaultValue);
        } catch (Exception e) {
            e.printStackTrace();
            return defaultValue;
        }
    }
}