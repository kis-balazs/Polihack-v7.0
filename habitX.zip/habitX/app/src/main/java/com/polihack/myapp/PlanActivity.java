package com.polihack.myapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 *  * COPYRIGHT :
 *  Hugs for Bugs team : Daczó Melinda, Florea Adrian, Kis Balázs
 *  Polihack v7.0 start of the app : local database, finite nr. of the lobby users.
 *
 *  2018.05.11
 */

public class PlanActivity extends AppCompatActivity {

    String pic_value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan);

        Intent intent = getIntent();
        final String username = intent.getStringExtra("username");

       Button button_time_set = (Button) findViewById(R.id.button_set_time);
        button_time_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText wake_time = (EditText) findViewById(R.id.wake_time);
                String WakeTime = wake_time.getText().toString();
                EditText sleep_time = (EditText) findViewById(R.id.sleep_time);
                String SleepTime = sleep_time.getText().toString();

                Intent intent = new Intent(PlanActivity.this, MainActivity.class);
                intent.putExtra("WTime", WakeTime);
                intent.putExtra("STime", SleepTime);
                intent.putExtra("pic_value", pic_value);
                intent.putExtra("username", username);
                PlanActivity.this.startActivity(intent);
                PlanActivity.this.finish();
            }
        });
    }
}
