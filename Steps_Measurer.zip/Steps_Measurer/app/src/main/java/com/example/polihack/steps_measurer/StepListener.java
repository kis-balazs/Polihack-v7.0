package com.example.polihack.steps_measurer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public interface StepListener {

    public void step(long timeNs);
}
