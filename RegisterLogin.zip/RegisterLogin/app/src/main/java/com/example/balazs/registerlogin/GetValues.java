package com.example.balazs.registerlogin;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class GetValues extends StringRequest {
    private static final String GET_VALUES_URL = "http://alchemical-professi.000webhostapp.com/GetValues.php";
    private Map<String, String> params;

    public GetValues(String username, Response.Listener<String> listener ){
        super(Request.Method.POST, GET_VALUES_URL, listener, null);
        params = new HashMap<>();
        params.put("username", username);
    }
    @Override
    public Map<String, String> getParams(){
        return params;
    }
}
