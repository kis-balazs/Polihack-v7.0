package com.example.balazs.registerlogin;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class WriteValues extends AppCompatActivity {

    int dailyValue = 0;
    int[] dailyValues = new int [6];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_values);

        String[] usernames = new String[6];
        usernames[0] = "admin";
        usernames[1] = "bkis";
        usernames[2] = "aflorea";
        usernames[3] = "mdaczo";
        usernames[4] = "hspaniol";
        usernames[5] = "cpocol";

        Response.Listener<String> responseListener = new Response.Listener<String>() {
                @Override public void onResponse(String response) {
                    try {
                        JSONObject jsonResponse = new JSONObject(response.substring(response.indexOf("{"), response.lastIndexOf("}") + 1));
                        boolean success = jsonResponse.getBoolean("success");

                        if (success) {
                            dailyValue = jsonResponse.getInt("dailyValue");

                        } else {
                            AlertDialog.Builder builder = new AlertDialog.Builder(WriteValues.this);
                            builder.setMessage("Database Fetch Error")
                                    .setNegativeButton("Retry", null)
                                    .create()
                                    .show();
                        }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
            };
            for(int i = 0; i < 6; i++) {
                GetValues values = new GetValues(usernames[i], responseListener);
                dailyValues[i] = dailyValue;
                RequestQueue queue = Volley.newRequestQueue(WriteValues.this);
                queue.add(values);
                Toast.makeText(getApplicationContext(),dailyValues[i] + "", Toast.LENGTH_LONG).show();
            }
    }
}


