package com.example.balazs.registerlogin;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class ImportValues extends StringRequest {

    private static final String IMPORT_VALUES_URL = "http://alchemical-professi.000webhostapp.com/ImportValues.php";
    private Map<String, String> params;

    public ImportValues(String username, String password, int nrDaysActive, int dailyValue, Response.Listener<String> listener ){
        super(Method.POST, IMPORT_VALUES_URL, listener, null);
        params = new HashMap<>();
        params.put("name", username);
        params.put("username", password);
        params.put("nrDaysActive", nrDaysActive + "");
        params.put("dailyValue", dailyValue + "");
    }

    @Override
    public Map<String, String> getParams(){
        return params;
    }

}